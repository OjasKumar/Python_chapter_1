#Author: Harry
#Licensed to: ABC Company
import os  # importing the os module
print("Hello world") 