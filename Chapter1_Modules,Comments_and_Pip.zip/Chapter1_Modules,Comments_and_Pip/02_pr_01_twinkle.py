print('''Twinke twinkle little star,
How i wonder what you 
Up above the world so high
Like a diamond in the sky ''')