from playsound import playsound
playsound( 'Downloads\\play.mp3' )