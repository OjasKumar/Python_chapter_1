# Author : Ojas
# Location : Mars
# Date : 23/09/2022

import os
print(os.listdir()) 